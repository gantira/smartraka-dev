<div class="auth_right">
    <div class="carousel slide" data-ride="carousel" data-interval="3000">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="{{ asset('assets/images/slider1.svg') }}" class="img-fluid" alt="login page" />
                <div class="px-4 mt-4">
                    <h4>Fully Responsive</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="{{ asset('assets/images/slider2.svg') }}" class="img-fluid" alt="login page" />
                <div class="px-4 mt-4">
                    <h4>Quality Code and Easy Customizability</h4>
                    <p>There are many variations of passages of Lorem Ipsum available.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="{{ asset('assets/images/slider3.svg') }}" class="img-fluid" alt="login page" />
                <div class="px-4 mt-4">
                    <h4>Cross Browser Compatibility</h4>
                    <p>Overview We're a group of women who want to learn JavaScript.</p>
                </div>
            </div>
        </div>
    </div>
</div>